m = float(input("Enter the first number of the triplet: "))
k = m/2
num2 = (k * k) - 1
num3 = (k * k) + 1
print(m,num2,num3)