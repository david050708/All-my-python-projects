import pyttsx3
from tkinter import *
from translate import Translator

#Translator function 
def translate():
    translator= Translator(from_lang=lan1.get(),to_lang=lan2.get())
    translation = translator.translate(var.get())
    var1.set(translation)

def speak():
    pyttsx3.speak(var1.get())



#Tkinter root Window with title
root = Tk()
root.title("AppDev Translator")
root.iconbitmap("C:/Users/kani/Downloads/1372756 (1).ico")

#Creating a Frame and Grid to hold the Content
mainframe = Frame(root)
mainframe.grid(column=0,row=0, sticky=(N,W,E,S) )
mainframe.columnconfigure(0, weight = 1)
mainframe.rowconfigure(0, weight = 1)
mainframe.pack(pady = 100, padx = 100)

#variables for dropdown list
lan1 = StringVar(root)
lan2 = StringVar(root)

#choices to show in dropdown menu
choices = { 'English','Hindi','Gujarati','Spanish','German','French',}
#default selection for dropdownlists
lan1.set('English')
lan2.set('Hindi')

#creating dropdown and arranging in the grid
lan1menu = OptionMenu( mainframe, lan1, *choices)
Label(mainframe,text="Select Input language").grid(row = 0, column = 1)
lan1menu.grid(row = 1, column =1)

lan2menu = OptionMenu( mainframe, lan2, *choices)
Label(mainframe,text="Select Output language").grid(row = 0, column = 2)
lan2menu.grid(row = 1, column =2)

#Text Box to take user input
Label(mainframe, text = "Enter text").grid(row=2,column=0)
var = StringVar()
textbox = Entry(mainframe, textvariable=var).grid(row=2,column=1)

#textbox to show output
#label can also be used
Label(mainframe, text = "Output").grid(row=2,column=2)
var1 = StringVar()
textbox = Entry(mainframe, textvariable=var1,state="readonly").grid(row=2,column=3)

#creating a button to call Translator function
b=Button(mainframe,text='Translate',bg="grey",fg="black",command=translate).grid(row=3,column=1,columnspan=3)
b2=Button(mainframe,text='Speak',bg="grey",fg="black",command=speak).grid(row=3,column=2,columnspan=4)
#Creating a button that notifies the user about the disadvantages of this app
Label(mainframe,text="Notice:\nThis app does not speak in the following languages\nHindi\nGujarati\n\nThank You").grid(row=5,column=6)

root.mainloop()