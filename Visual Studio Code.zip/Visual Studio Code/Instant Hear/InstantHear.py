import pyttsx3
from tkinter import *
import tkinter as tk

root = tk.Tk()
root.geometry("500x500")
root.title("Instant Hear")
root.iconbitmap("C:/Users/kani/Downloads/hnet.com-image.ico")

text=Entry(root,width=50,bg="white",fg="black",font=("arial","16"))
text.pack(padx=10,pady=20)

def Help():
    pyttsx3.speak("hello there, i am your Instant Hear app Voice module, just type anything in the entry box and click the hear button, Thank You")

def Hear():
    pyttsx3.speak(text.get())

def about():
    pyttsx3.speak("Instant hear is app created by AppDev, version, 1 point 1 point 0")
    
x = tk.StringVar()
b1 = tk.Button(root,text="Hear",fg="black",bg="lightgrey",command=Hear).pack()
b2 = tk.Button(root,text="Help?",fg="black",bg="lightgrey",command=Help).pack()
b3 = tk.Button(root,text="About",fg="black",bg="lightgrey",command=about).pack()

root.mainloop()
