from tkinter import *
import tkinter as tk
import pyttsx3

root = Tk()
root.geometry("500x500")
root.title("Instant Hear 2")
root.iconbitmap("C:/Users/kani/Downloads/hnet.com-image.ico")

x = StringVar()
text = tk.Entry(root,width=50,bg="white",fg="black")
text.place(x=85,y=10,height=30,width=320)

def speak():
    pyttsx3.speak(text.get())


# create menu
MenuBar = Menu(root)
root.config(menu=MenuBar)

# configure File and Edit menus with MenuBar
EditMenu = Menu(MenuBar , tearoff=0)
HelpMenu = Menu(MenuBar , tearoff=0)
MenuBar.add_cascade(label="Edit",menu=EditMenu)
MenuBar.add_cascade(label="About",menu=HelpMenu)

def about():
    root = tk.Tk()
    root.resizable(0,0)
    root.title("About")

    label = Label(root,text="Instant Hear Version 2.0\n\n").pack()

    root.mainloop()

def exitFile():
    root.destroy()
    
def cut():
    text.event_generate(("<<Cut>>"))
    
def copy():
    text.event_generate(("<<Copy>>"))
    
def paste():
    text.event_generate(("<<Paste>>"))

# adding cut, copy, paste functionalities to Edit menu
EditMenu.add_command(label = "Cut" , command = cut)
EditMenu.add_command(label = "Copy" , command = copy)
EditMenu.add_command(label = "Paste" , command = paste)

#adding help menu to about
HelpMenu.add_command(label = "About Instant hear 2", command = about)


x = StringVar()
b1 = Button(root,text="Hear",bg="grey",fg="black",command=speak)
b2 = Button(root,text="Close",bg="grey",fg="black",command=exit)
b1.place(x=85,y=70,height=30,width=320)
b2.place(x=85,y=120,height=30,width=320)

root.mainloop()