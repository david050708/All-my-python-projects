import pyttsx3
import tkinter as tk
from tkinter import *

root = tk.Tk()
root.title("Instant Hear Version 2")
root.geometry("500x500")

#Label about the app
lbl = Label(root,text = "This is a new version of AppDev Instant Hear with Bug Fixes\n\n\nThank You").pack()

var1 = Entry(root,width=100,bg="white",fg="black")
var1.pack(padx=10,pady=20)

def hear():
    pyttsx3.speak(var1.get())

b = tk.Button(root,text="Hear",bg="grey",fg="black",command=hear).pack()

root.mainloop()
