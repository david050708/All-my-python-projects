from math import sqrt

print('Pythagorean theorem calculator! Calculate your triangle sides.\nAlso Calculate Pythagorean Triplets')
print('Let the sides of the triangle be a, b, c and c as the hypotenuse (the side opposite the right angle')
option = input('Which side (a, b, c) do you wish to calculate? side: ')

if option == 'c':
	side_a = float(input('Input the length of side a: '))
	side_b = float(input('Input the length of side b: '))

	side_c = sqrt(side_a * side_a + side_b * side_b)
	
	print('The length of side (c) is: ' )
	print(side_c)

elif option == 'a':
    side_b = float(input('Input the length of side b: '))
    side_c = float(input('Input the length of side c: '))
    
    side_a = sqrt((side_c * side_c) - (side_b * side_b))
    
    print('The length of side (a) is' )
    print(side_a)

elif option == 'b':
    side_a = float(input('Input the length of side a: '))
    side_b = float(input('Input the length of side c: '))
        
    side_c = sqrt(side_b * side_b - side_a * side_a)
    
    print('The length of side (b) is')
    print(side_c)

else:
	print('Please select a side between a, b, c')