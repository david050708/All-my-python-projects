m = float(input("Enter the first number of the Pythagorean Triplet: "))
k = m/2
num1 = (k *k) - 1
num2 = (k * k) + 1
print(m,num1,num2)
