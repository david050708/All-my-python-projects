from tkinter import *
from math import sqrt

root=Tk()
root.title("Pythagorean Theorem Calculator")
root.geometry("500x500")

f1=Frame(root, width=400, height=20)
f1.pack()
f2=Frame(root, width=420, height=20)
f2.pack()

var_a=StringVar()
var_b=StringVar()
var_c=StringVar()

# Initial welcome; then asks which side of triangle to solve for
def start():
    welcome_label=Label(f1, text="Welcome to the Pythagorean Theorem Calculator! And Solve Pythagoren Triplets ", fg="red")
    solve_for=Label(f1, text="Would you like to solve for A, B, or C?")
    button_a=Button(f2, text="Solve for A", fg="red", command = solve_a)
    button_b=Button(f2, text="Solve for B", fg="red", command = solve_b)
    button_c=Button(f2, text="Solve for C (Hypotenuse)", fg="red", command = solve_c)

    welcome_label.pack()
    solve_for.pack()
    button_a.pack(side=LEFT)
    button_b.pack(side=LEFT)
    button_c.pack(side=LEFT)


# Math, labels, buttons, and frames to solve for A
def solve_a():
    f1.pack_forget()
    f2.pack_forget()
    new_frame=Frame(root)
    new_frame.pack()

    def ans_a():
        new_frame.pack_forget()
        new_frame1=Frame(root)
        new_frame1.pack()
        value_b=float(var_b.get())
        value_c=float(var_c.get())
        a=sqrt((value_c**2)-(value_b**2))
        ans=Label(new_frame1, text=("The value of A is: "+str(a)))
        ans.pack()


    label_b=Label(new_frame, text="Value of B:")
    label_c=Label(new_frame, text="Value of C:")
    e1=Entry(new_frame, textvariable=var_b)
    e2=Entry(new_frame, textvariable=var_c)
    submit=Button(new_frame, text="Submit", fg="red", command=ans_a)

    label_b.grid(row=0, sticky=W)
    label_c.grid(row=1, sticky=W)
    e1.grid(row=0, column=1)
    e2.grid(row=1, column=1)
    submit.grid(row=2, column=1)



# Math, labels, buttons, and frames to solve for B
def solve_b():
    f1.pack_forget()
    f2.pack_forget()
    new_frame=Frame(root)
    new_frame.pack()

    def ans_b():
        new_frame.pack_forget()
        new_frame1=Frame(root)
        new_frame1.pack()
        value_a=float(var_a.get())
        value_c=float(var_c.get())
        b=sqrt((value_c**2)-(value_a**2))
        ans=Label(new_frame1, text=("The value of B is: "+str(b)))
        ans.pack()

    label_a=Label(new_frame, text="Value of A:")
    label_c=Label(new_frame, text="Value of C:")
    e1=Entry(new_frame, textvariable=var_a)
    e2=Entry(new_frame, textvariable=var_c)
    submit=Button(new_frame, text="Submit", fg="red", command=ans_b)

    label_a.grid(row=0, sticky=W)
    label_c.grid(row=1, sticky=W)
    e1.grid(row=0, column=1)
    e2.grid(row=1, column=1)
    submit.grid(row=2, column=1)



# Math, labels, buttons, and frames to solve for C
def solve_c():
    f1.pack_forget()
    f2.pack_forget()
    new_frame=Frame(root)
    new_frame.pack()

    def ans_c():
        new_frame.pack_forget()
        new_frame1=Frame(root)
        new_frame1.pack()
        value_a=float(var_a.get())
        value_b=float(var_b.get())
        c=sqrt((value_a**2)+(value_b**2))
        ans=Label(new_frame1, text=("The value of C is: "+str(c)))
        ans.pack()

    label_a=Label(new_frame, text="Value of A:")
    label_b=Label(new_frame, text="Value of B:")
    e1=Entry(new_frame, textvariable=var_a)
    e2=Entry(new_frame, textvariable=var_b)
    submit=Button(new_frame, text="Submit", fg="red", command=ans_c)

    label_a.grid(row=0, sticky=W)
    label_b.grid(row=1, sticky=W)
    e1.grid(row=0, column=1)
    e2.grid(row=1, column=1)
    submit.grid(row=2, column=1)




# Calls the initial welcome screen
start()
root.mainloop()