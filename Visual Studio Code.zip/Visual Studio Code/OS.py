import tkinter as tk
import webbrowser
import os
from tkinter import *
from playsound import playsound


root = Tk()
root.title("OS")
root.geometry("500x500")

label1 = Label(root,text="Login").pack()
login = Entry(root,width="50",bg="white",fg="black")
login.pack()

label2 = Label(root,text="Password").pack()
password = Entry(root,width="50",bg="white",fg="black")
password.pack()



def go():
    if login.get() == "DJ050708":
        if password.get() == "david050708":
            playsound("C:/Users/kani/Downloads/windows-10-startup-sound_tune-online-audio-converter.mp3")
            import tkinter as tk
            import os
            
            r = Tk()
            r.title("OS Entered")
            r.geometry("300x300")

            def open():
                os.startfile("C:/")
            
            b1 = tk.Button(root,text="Open File Explorer",bg="grey",fg="black",command=open).pack()


            r.mainloop()

    else:
        label2 = Label(root,text="Password or Login is Incorrect\nPlease try again").pack()


b1 = tk.Button(root,text="Go",bg="grey",fg="black",command=go).pack()
b2 = tk.Button(root,text="ShutDown",bg="grey",fg="black",command=exit).pack()

root.mainloop()