import subprocess
subprocess.call(["shutdown", "/s"])