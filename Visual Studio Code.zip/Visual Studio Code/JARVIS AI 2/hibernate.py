import os
os.system("shutdown.exe /h")