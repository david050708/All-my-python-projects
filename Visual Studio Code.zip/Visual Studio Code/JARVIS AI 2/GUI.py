import win32com.client
import threading
import os as spacy
import sqlite3
import operator
from collections import OrderedDict
import matplotlib.pyplot as plt
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import nltk
from tkinter import *
speaker = win32com.client.Dispatch("SAPI.SpVoice")

jarvis = ChatBot("JARVIS")

jarvis.set_trainer(ListTrainer)

def parse(url):
	try:
		parsed_url_components = url.split('//')
		sublevel_split = parsed_url_components[1].split('/', 1)
		domain = sublevel_split[0].replace("www.", "")
		return domain
	except IndexError:
		print ("URL format error!")

def analyze(results):

	prompt = input("[.] Type <c> to print or <p> to plot\n[>] ")

	if prompt == "c":
		for site, count in sites_count_sorted.items():
			print (site, count)
	elif prompt == "p":
		plt.bar(range(len(results)), results.values(), align='edge')
		plt.xticks(rotation=90)
		plt.xticks(range(len(results)), results.keys())
		plt.show()
	else:
		print ("[.] Uh?")
		quit()

#path to user's history database (Chrome)
data_path = "chrome://history//"
files = spacy.listdir(data_path)

history_db = spacy.path.join(data_path, 'history')

#querying the db
c = sqlite3.connect(history_db)
cursor = c.cursor()
select_statement = "SELECT urls.url, urls.visit_count FROM urls, visits WHERE urls.id = visits.url;"
cursor.execute(select_statement)

results = cursor.fetchall() #tuple

sites_count = {} #dict makes iterations easier :D

for url, count in results:
	url = parse(url)
	if url in sites_count:
		sites_count[url] += 1
	else:
		sites_count[url] = 1

sites_count_sorted = OrderedDict(sorted(sites_count.items(), key=operator.itemgetter(1), reverse=True))

analyze (sites_count_sorted)

'''
jarvis.train([
    "Hi there!",
    "Hello",
    "Ola",
    "Hi what's up !",
    "Howdy"
])'''
identity = ["who are you","my name is jarvis,i am here to help you","what is your name","jarvis"]
#jarvis.train(identity)

response = jarvis.get_response("what is you name")

string = "open my computer"
print(string.find("open"))
text = nltk.word_tokenize(string)
print(nltk.pos_tag(text))
print(response)

'''def speek():'''

class App(threading.Thread):

    def __init__(self):
        threading.Thread.__init__(self)
        self.start()

    def callback(self):
        self.quit()

    def run(self):
        self.root = Tk()
        self.root.title("JARVIS 1.0")
        self.root.option_add("*background", "black")
        self.root.state('zoomed')
        img = PhotoImage(file="D:\\8th Notes\\Visual Studio Code\\reactor.gif")
        panel = Label(self.root, image=img)
        panel.pack(side="bottom", fill="both", expand="yes")

        '''b = Button(text="Welcome Sir",command = speek)
        '''
        '''b.pack()'''
        self.root.mainloop()


app = App()



speaker.Speak("Hello sir, Welcome to the JARVIS 1.0")