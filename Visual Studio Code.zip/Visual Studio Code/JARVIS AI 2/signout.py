import subprocess
subprocess.call(["shutdown", "/l"])