import subprocess
subprocess.call(["shutdown", "/r"])