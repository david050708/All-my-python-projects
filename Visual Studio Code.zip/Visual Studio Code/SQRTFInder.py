from math import sqrt
num1 = float(input("Enter the number: "))
print(sqrt(num1))