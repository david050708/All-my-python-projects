import pyttsx3

print("Happy Birthday Kanisham may God bless you, have a wonderful year ahead, from David")
pyttsx3.speak("Happy Birthday Kanisham, may God bless you, have a wonderful year ahead, from David")