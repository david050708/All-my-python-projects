from tkinter import *
import tkinter as tk

r = Tk()
r.title("Apps installed")
r.geometry("500x500")

apps = "Zoom\nPowerpoint\nWord\nExcel\nAccess\nVisual Studio\nQT Designer\nPython\nChrome\nOffice\nOutLook\nMS EDGE"

label1 = Label(r,text=apps).pack()

r.mainloop()