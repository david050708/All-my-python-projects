from tkinter import *
import pyttsx3
import webbrowser

root = Tk()
root.title("J.A.R.V.I.S")
root.geometry("600x700")

query = Entry(root,width=50,bg="white",fg="black")
query.pack(padx=10,pady=20)

command = query.get()

def go():
	if 'hello' in query.get() or 'hi' in query.get():
		pyttsx3.speak("Hello There")
		print("Hello There")
	
	if '.com' in query.get() or '.org' in query.get():
		webbrowser.open_new(query.get())

b = Button(root,text="Go",bg="grey",fg="black",command = go).pack()

root.mainloop
